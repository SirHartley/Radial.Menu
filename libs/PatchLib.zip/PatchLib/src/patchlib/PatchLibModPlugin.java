package patchlib;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.sun.tools.attach.AgentInitializationException;
import com.sun.tools.attach.AgentLoadException;
import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;
import org.apache.log4j.Logger;
import patchlib.agent.AgentMain;
import patchlib.test.PatchLibTests;

import javax.management.ObjectName;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PatchLibModPlugin extends BaseModPlugin {

    private static final Logger log = Global.getLogger(PatchLibModPlugin.class);

    @Override
    public void onApplicationLoad() throws Exception {

        //If the agent is already attached at this point, it was loaded through the -javaagent flag in the vmparams.
        String attachMethod = "-javaagent";
        if (!checkAlreadyAttached()) {
            attachMethod = "self-attach";
            try {
                selfAttachAgent();
            } catch (Throwable attachEx) {
                //Self-attach can throw after agentmain already ran, in which case loading it a second time is not needed.
                if (!checkAlreadyAttached()) {
                    attachMethod = "diagnostic command";
                    log.warn("[PatchLib] Normal self-attach failed (" + attachEx + ").");
                    log.warn("[PatchLib] Falling back to loading the agent through the JVMs diagnostic command");
                    try {
                        loadAgentThroughDiagnosticCommand();
                        log.info("[PatchLib] Loaded the agent through the diagnostic command fallback.");
                    } catch (Throwable fallbackEx) {
                        logAgentAttach("failed");
                        //Both attempts failed. The fallbacks error is the cause, the self-attach error is kept as suppressed so both show up in the log.
                        String message = "PatchLib failed to attach to the game. \n";
                        //More specific error warning for crash due to issues with pre 0.7.0 Fast rendering.
                        if (String.valueOf(fallbackEx.getMessage()).contains("return code: 101")) {
                            message = "PatchLib self attach with the diagnostic command failed with error code 101.\n\n" +
                                    "This may be because you are on an older version of the \"Fast Rendering\" mod. Try updating it before reporting an issue.\n";
                        }
                        RuntimeException ex = new RuntimeException(message, fallbackEx);
                        ex.addSuppressed(attachEx);
                        throw ex;
                    }
                }
            }
        }

        logAgentAttach(attachMethod);

        //Init the agent if it managed to attach.
        //Pass the mod classloader, as it is needed to bind the patches method handlers later.
        AgentMain.init(this.getClass().getClassLoader());

        PatchLibTests patchLibTests = new PatchLibTests();
        patchLibTests.runTests();
    }

    @Override
    public void onGameLoad(boolean newGame) {
        AgentMain.releaseScanData();
    }

    /** Check if the agent was already attached by a -javaagent flag in the vmparams. */
    public boolean checkAlreadyAttached() {
        String isAttached = System.getProperty("PatchLib_AgentAttached");
        return isAttached != null;
    }

    /** Self-attaches PatchLib's agent to the game.
     * Should be stable, as long as:
     * 1. The game ships with the "jdk.attach" module included in the bundled JRE/JDK.
     * 2. The game has the "-Djdk.attach.allowAttachSelf=true -XX:+EnableDynamicAgentLoading" flags set in the vmparams.
     * Alex has confirmed that both of those will happen with v0.98.5a
     * */
    public void selfAttachAgent() throws AgentLoadException, IOException, AgentInitializationException, AttachNotSupportedException {
        String agentJar = relativeToWorkingDir(getAgentJarPath());

        String pid = Long.toString(ProcessHandle.current().pid());

        VirtualMachine vm = VirtualMachine.attach(pid);
        vm.loadAgent(agentJar);
        vm.detach();
    }

    /** Fallback for when jdk.attach style self-attach is not available, i.e. if the bundled JRE lacks the "jdk.attach" module.
     * Invokes HotSpots "JVMTI.agent_load" diagnostic command on the running JVM, which loads a .jar as a java agent
     * and calls its agentmain before returning. */
    public void loadAgentThroughDiagnosticCommand() throws Exception {
        String agentJar = relativeToWorkingDir(getAgentJarPath());

        Object output = ManagementFactory.getPlatformMBeanServer().invoke(
                new ObjectName("com.sun.management:type=DiagnosticCommand"),
                "jvmtiAgentLoad",
                new Object[]{ new String[]{ "\"" + agentJar + "\"" } },
                new String[]{ String[].class.getName() });

        //The command reports some failures through its output instead of an exception, so confirm that agentmain ran.
        if (!checkAlreadyAttached()) {
            throw new IllegalStateException("The diagnostic command did not load the agent. Command output: " + String.valueOf(output).trim());
        }
    }

    /** Returns the path relative to the working directory, or the path unchanged if that is not possible (i.e. different drives).
     * Both agent loading paths fail on absolute Windows paths with non-ASCII characters, but accept relative ones. */
    private String relativeToWorkingDir(String path) {
        try {
            Path workingDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
            return workingDir.relativize(Paths.get(path).toAbsolutePath().normalize()).toString();
        } catch (Exception e) {
            return path;
        }
    }

    private String getAgentJarPath() {
        ModSpecAPI modSpec = Global.getSettings().getModManager().getModSpec("patchlib");
        return modSpec.getPath() + "/jars/PatchLibAgent.jar";
    }

    /** Logs the version, Java runtime, OS and attach method in a single line, so that most issue reports can be narrowed down from the log alone. */
    private void logAgentAttach(String attachMethod) {
        String version = Global.getSettings().getModManager().getModSpec("patchlib").getVersion();
        String java = System.getProperty("java.runtime.version") + " (" + System.getProperty("java.vendor") + ")";
        String os = System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")";

        log.info("[PatchLib] Version " + version + " | Java " + java + " | " + os + " | Attach: " + attachMethod);
    }



}
